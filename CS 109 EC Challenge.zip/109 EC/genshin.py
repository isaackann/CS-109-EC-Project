import random
import numpy as np


# class to hold the probabilities of artifact main stats
class PIECE_STATS:
    FLOWER =  {0: 'HP'}
    FEATHER = {0: 'ATK'}
    SANDS =   {73.32: 'HP%', 46.66: 'ATK%', 20: 'DEF%', 10: 'ER%', 0: 'EM'}
    GOBLET =  {80.75: 'HP%', 61.5: 'ATK%', 42.5: 'DEF%', 37.5: 'PYRO%', 32.5: 'ELECTRO%', 27.5: 'CRYO%', 22.5: 'HYDRO%', 17.5: 'DENDRO%', 
               12.5: 'ANEMO%', 7.5: 'GEO%', 2.5: 'PHYS%', 0.0: 'EM'}
    CIRCLET = {78: 'HP%', 56: 'ATK%', 34: 'DEF%', 24: 'CR%', 14: 'CD%', 4: 'HB%', 0: 'EM'}
    
    fxn_dict = {'Flower': FLOWER, 'Feather': FEATHER, 'Sands': SANDS, 'Goblet': GOBLET, 'Circlet': CIRCLET}
    
    def match(piece):  # matches artifact type to its dictionary of mainstats
        return PIECE_STATS.fxn_dict[piece]


# class to hold substats and their probabilities for each artifact type & mainstat
class SUBSTATS:
    FLOWER =  {'Stat':   ['ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'], 
              'Weight':  [15.79, 15.79, 10.53, 10.53, 10.53, 10.53, 10.53, 7.89, 7.89]}
    FEATHER = {'Stat':   ['HP', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
               'Weight': [15.79, 15.79, 10.53, 10.53, 10.53, 10.53, 10.53, 7.89, 7.89]}
    ALL =     {'Stat':   ['HP', 'ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
               'Weight': [13.64, 13.64, 13.64, 9.09, 9.09, 9.09, 9.09, 9.09, 6.82, 6.82]} 
    
    # because sands, goblets, and circlets have different substat distributions based on mainstat, these functions
    # look at mainstat and provide the corresponding distribution
    def get_sands(mainstat):
        sands_dict = {'Stat':   ['HP', 'ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
                      'Weight': [15, 15, 15, 10, 10, 10, 10, 7.5, 7.5]}
        sands_dict['Stat'].remove(mainstat)
        
        return sands_dict
    
    def get_goblet(mainstat):
        elements = ['PYRO%', 'ELECTRO%', 'CRYO%', 'HYDRO%', 'DENDRO%', 'ANEMO%', 'GEO%', 'PHYS%']
        
        if mainstat in elements:
            return SUBSTATS.ALL
        
        else:
            goblet_dict = {'Stat':   ['HP', 'ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
                           'Weight': [15, 15, 15, 10, 10, 10, 10, 7.5, 7.5]}
            goblet_dict['Stat'].remove(mainstat)
            
            return goblet_dict        
    
    def get_circlet(mainstat):
        if mainstat == 'CR%' or mainstat == 'CD%':
            circlet_dict = {'Stat':   ['HP', 'ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
                            'Weight': [14.63, 14.63, 14.63, 9.76, 9.76, 9.76, 9.76, 9.76, 7.32]}
            circlet_dict['Stat'].remove(mainstat)
            
            return circlet_dict
        
        elif mainstat == 'HB%':
            return SUBSTATS.ALL
        
        else:
            circlet_dict = {'Stat':   ['HP', 'ATK', 'DEF', 'HP%', 'ATK%', 'DEF%', 'ER%', 'EM', 'CR%', 'CD%'],
                            'Weight': [15, 15, 15, 10, 10, 10, 10, 7.5, 7.5]}
            circlet_dict['Stat'].remove(mainstat)
            
            return circlet_dict              
    

# run-of-the-mill bernoulli function
def bernoulli(p):
    return int(random.uniform(0, 1) < p)


# determines the artifact set (1 of 2 sets with equal probability)
def set():
    if bernoulli(0.5): return 'EOSF'
    
    return 'SHIM'


def piece_roller():
    pieces = ['Flower', 'Feather', 'Sands', 'Goblet', 'Circlet']
    return random.choice(pieces)


def mainstat_roller(piece_type):
    statsDict = PIECE_STATS.match(piece_type)   
    magic_num = random.uniform(0, 100)
    
    for threshold, stat in statsDict.items():
        if magic_num > threshold: return stat
        
        
def substat_roller(piece, mainstat):
    if bernoulli(0.8): num_subs = 3
    else: num_subs = 4

    if   piece == 'Flower':  subs = SUBSTATS.FLOWER
    elif piece == 'Feather': subs = SUBSTATS.FEATHER
    elif piece == 'Sands':   subs = SUBSTATS.get_sands(mainstat)
    elif piece == 'Goblet':  subs = SUBSTATS.get_goblet(mainstat)
    elif piece == 'Circlet': subs = SUBSTATS.get_circlet(mainstat)

    substats = []
    
    while (len(substats) < num_subs):
        interim_stat = random.choices(subs['Stat'], weights=subs['Weight'])
        
        if interim_stat[0] not in substats:
            substats.append(interim_stat[0])
    
    return substats


def make_piece():
    piece_set = set()
    piece_type = piece_roller()
    piece_mainstat = mainstat_roller(piece_type)
    substats = substat_roller(piece_type, piece_mainstat)
    
    # print(piece_type, piece_mainstat, substats)
    return piece_set, piece_type, piece_mainstat, substats
        

# DO NOT USE
def piece_classifier(type, mainstat, substats):
    hasCrit = 'CR%' in substats or 'CD%' in substats
    hasDoubleCrit = 'CR%' in substats and 'CD%' in substats
    
    if type == 'Flower' or type == 'Feather':
        if hasDoubleCrit: return 'AWESOME'
        elif len(substats) == 3 and hasCrit: return 'GOOD'
        elif hasCrit: return 'OK'
        return 'BAD'
    
    elif type == 'Sands':
        good = ['ATK%', 'ER%', 'EM']
        if mainstat not in good: return 'BAD'
        
        if hasDoubleCrit: return 'AWESOME'
        elif len(substats) == 3 and hasCrit: return 'GOOD'
        elif hasCrit: return 'OK'
        return 'BAD'
    
    elif type == 'Goblet':
        elements = ['PYRO%', 'ELECTRO%', 'CRYO%', 'HYDRO%', 'DENDRO%', 'ANEMO%', 'GEO%', 'PHYS%']
        if mainstat not in elements: return 'BAD'
        
        elif hasDoubleCrit: return 'AWESOME'
        elif len(substats) == 3 and hasCrit: return 'GOOD'
        elif hasCrit: return 'OK'
        return 'BAD'

    elif type == 'Circlet':
        if mainstat == 'CR%' or mainstat == 'CD%':
            if hasCrit: return 'GOOD'
            return 'OK'
        return 'BAD'


def roll_sim(piece_type, mainstat, substats):
    roll_dict = {}
    
    for stat in substats:
        roll_dict[stat] = 1
        
    tracker = 5
    
    # simulate an artifact with 3 substats rolling a 4th substat
    while len(roll_dict) < 4:
        tracker -= 1
        new_subs = substat_roller(piece_type, mainstat)
        
        for sub in new_subs:
            if sub not in roll_dict:
                roll_dict[sub] = 1
                break
                
    for i in range(tracker):
            choice = random.choice(substats)
            roll_dict[choice] += 1
            
    return roll_dict


# determines the crit value (CV) of an artifact
def cv_classifier(roll_dict):
    cv = 0
    
    for key, value in roll_dict.items():
        if key == 'CD%' or key == 'CR%':
            cv += value * 6.6
    
    return round(cv, 3)


# stricter requirements for classifying an artifact as 'GOOD', based on its CV and mainstat
def strict_classifier(piece_type, mainstat, roll_dict):
    cv = cv_classifier(roll_dict)
    
    if (piece_type == 'Flower' or piece_type == 'Feather') and cv >= 30: return 'GOOD'
    elif piece_type == 'Sands':
        good_stats = ['ATK%', 'ER%', 'EM']
        if mainstat in good_stats and cv >= 30: return 'GOOD'   
    elif piece_type == 'Goblet':
        elements = ['PYRO%', 'ELECTRO%', 'CRYO%', 'HYDRO%', 'DENDRO%', 'ANEMO%', 'GEO%', 'PHYS%']
        if mainstat in elements and cv >= 30: return 'GOOD'
    # different CV threshold for circlets (only 1 crit substat possible)
    elif piece_type == 'Circlet' and (mainstat == 'CR%' or mainstat == 'CD%') and cv >= 15: return 'GOOD' 
    
    return 'BAD'
    

# less strict requirements for classifying an artifact as 'GOOD', based on its CV and mainstat
def lenient_classifier(piece_type, mainstat, roll_dict):
    cv = cv_classifier(roll_dict)
    
    if (piece_type == 'Flower' or piece_type == 'Feather') and cv >= 20: return 'GOOD'
    elif piece_type == 'Sands':
        good_stats = ['ATK%', 'ER%', 'EM']
        if mainstat in good_stats and cv >= 20: return 'GOOD'   
    elif piece_type == 'Goblet':
        elements = ['PYRO%', 'ELECTRO%', 'CRYO%', 'HYDRO%', 'DENDRO%', 'ANEMO%', 'GEO%', 'PHYS%']
        if mainstat in elements and cv >= 20: return 'GOOD'
    # different CV threshold for circlets (only 1 crit substat possible)
    elif piece_type == 'Circlet' and (mainstat == 'CR%' or mainstat == 'CD%') and cv >= 10: return 'GOOD' 
    
    return 'BAD'    
    
    
def build_helper(arti_set, sands_stat, goblet_stat, circlet_stat, char_build, tracker):
    piece_set, artifact_type, mainstat, substats = make_piece()
    roll_dict = roll_sim(artifact_type, mainstat, substats)        
    arti_class = lenient_classifier(artifact_type, mainstat, roll_dict)
    cv = cv_classifier(roll_dict)
    
    # good artifact of the class we want
    if (cv >= 30 or (cv >= 15 and artifact_type == 'Circlet')) and piece_set == arti_set:
            if (artifact_type == 'Flower' or artifact_type == 'Feather'):
                tracker[artifact_type] = True
                char_build[artifact_type] = (piece_set, mainstat, roll_dict)
            elif artifact_type == 'Sands' and mainstat == sands_stat:
                tracker[artifact_type] = True
                char_build[artifact_type] = (piece_set, mainstat, roll_dict)
            elif artifact_type == 'Goblet' and mainstat == goblet_stat:
                tracker[artifact_type] = True
                char_build[artifact_type] = (piece_set, mainstat, roll_dict)
            elif artifact_type == 'Circlet' and mainstat == circlet_stat:
                tracker[artifact_type] = True
                char_build[artifact_type] = (piece_set, mainstat, roll_dict) 


def build_stats(build_dict):
    CR = 36.1
    CD = 50
    
    for piece, piece_info in build_dict.items():
        substats = piece_info[2]
        if 'CD%' in substats: CD += substats['CD%'] * 6.6
        if 'CR%' in substats: CR += substats['CR%'] * 3.3
        
    return {'CR': round(CR, 3), 'CD': round(CD, 3)}


def build_char(arti_set, sands_stat, goblet_stat, circlet_stat):
    num_trials = 0
    
    char_build = {'Flower':  ("", "", {}), 
                  'Feather': ("", "", {}),
                  'Sands':   ("", "", {}),
                  'Goblet':  ("", "", {}),
                  'Circlet': ("", "", {})}
    
    tracker = {}
    
    while len(tracker) < 5:
        num_trials += 1
        build_helper(arti_set, sands_stat, goblet_stat, circlet_stat, char_build, tracker)
        
        # 6.5% chance to get 2 artifacts from a single domain run
        if bernoulli(0.065):
            build_helper(arti_set, sands_stat, goblet_stat, circlet_stat, char_build, tracker)

    # print(build_stats(char_build), char_build)
    return num_trials
