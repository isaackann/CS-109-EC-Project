
from PIL import Image, ImageDraw, ImageFont
import genshin as G
import utility as ut
import numpy as np
import plotly.express as px
import pandas as pd

font = ImageFont.truetype('genshin_font.ttf', 21)
font_inc = 35

substats = {'HP': 254, 'HP%': 5.0, 'ATK': 17, 'ATK%': 5.0, 'DEF': 20, 'DEF%': 6.2, 'EM': 20, 'ER%': 5.5, 
            'CR%': 3.3, 'CD%': 6.6}
displays = {'HP': 'HP', 'HP%': 'HP', 'ATK': 'ATK', 'ATK%': 'ATK', 'DEF': 'DEF', 'DEF%': 'DEF', 
            'EM': 'Elemental Mastery', 'ER%': 'Energy Recharge', 'CR%': 'CRIT Rate', 'CD%': 'CRIT DMG'}


# draws artifact stats onto blank template
def draw_artifact(piece_set, artifact_type, mainstat, roll_dict):
    image_name = f'images/{piece_set}_{artifact_type}_{mainstat}.png'
    img = Image.open(image_name).resize((441, 492))
    draw = ImageDraw.Draw(img)
    tracker = 0
    
    # draw all 4 substats on blank artifact tempalte
    for substat, rolls in roll_dict.items():
        to_display = str(round(substats[substat] * rolls, 1))
        display_sub = displays[substat]
        
        # ensure proper name for displaying substat
        if substat[-1] == '%':
            to_display += '%'
        
        draw.text((20, 320 + font_inc * tracker), f'• {display_sub}+{to_display}', font = font, fill='#495465')
        tracker += 1
        
    img.show()
    
    
# sim function calling genshin.py functions
def display_sim():
    piece_set, artifact_type, mainstat, substats = G.make_piece()
    roll_dict = G.roll_sim(artifact_type, mainstat, substats)
    draw_artifact(piece_set, artifact_type, mainstat, roll_dict)


# sim function for trying to get a 30 CV artifact
def cv30_display_sim():
    n = input(f'Please enter {ut.ANSI.BLUE}desired artifact Crit Value{ut.ANSI.RESET}: ') 
    n = int(n)
    
    tracker = False
    count = 0
    
    while tracker == False:
        piece_set, artifact_type, mainstat, substats = G.make_piece()
        roll_dict = G.roll_sim(artifact_type, mainstat, substats)
        count += 1
            
        if G.cv_classifier(roll_dict) >= n: 
            draw_artifact(piece_set, artifact_type, mainstat, roll_dict)
            print(f'{ut.ANSI.BLUE}{count} trials needed to produce an artifact with {n}+ CV{ut.ANSI.RESET}')
            tracker = True
            

# creates bar chart for build statistics
def draw_build_sim(total):
    df = pd.DataFrame(data={'Number of Rolls': total})
    fig = px.histogram(df, x='Number of Rolls', nbins=25, title=f'Number of Trials to Build a Character (x{len(total)})')
    fig.update_layout(bargap=0.2, yaxis_title='Number of Trials')
    fig.show()


# sims building a character using a strict classifier
def build_sim():
    sands, goblet, circlet = '', '', ''
    
    # user inputs desired artifact stats
    while sands == '':
        new_input = input(f'Please enter {ut.ANSI.CYAN}sands mainstat{ut.ANSI.RESET} ({list(G.PIECE_STATS.SANDS.values())}): ')
        if new_input in G.PIECE_STATS.SANDS.values(): sands = new_input
        else: print(f'{ut.ANSI.BRIGHT_RED}Please enter a valid mainstat ({list(G.PIECE_STATS.SANDS.values())}){ut.ANSI.RESET}')

    while goblet == '':
        new_input = input(f'Please enter {ut.ANSI.CYAN}goblet mainstat{ut.ANSI.RESET} ({list(G.PIECE_STATS.GOBLET.values())}): ')
        if new_input in G.PIECE_STATS.GOBLET.values(): goblet = new_input
        else: print(f'{ut.ANSI.BRIGHT_RED}Please enter a valid mainstat ({list(G.PIECE_STATS.GOBLET.values())}){ut.ANSI.RESET}')

    while circlet == '':
        new_input = input(f'Please enter {ut.ANSI.CYAN}circlet mainstat{ut.ANSI.RESET} ({list(G.PIECE_STATS.CIRCLET.values())}): ')
        if new_input in G.PIECE_STATS.CIRCLET.values(): circlet = new_input
        else: print(f'{ut.ANSI.BRIGHT_RED}Please enter a valid mainstat ({list(G.PIECE_STATS.CIRCLET.values())}){ut.ANSI.RESET}')
    
    total = []
    for i in range(100):
        total.append(G.build_char('EOSF', sands, goblet, circlet))
      
    draw_build_sim(total)  # display histogram

    total = np.mean(total)  # print statistics
    print(f"{ut.ANSI.BLUE}On average, {round(total, 2)} artifact runs were needed to build the character")
    print(f"This is equivalent to {round(total * 20, 2)} original resin, or {round(total * 20 / 180, 2)} days of gameplay{ut.ANSI.RESET}")
    
    
# simulate rolling 1,000,000 artifacts and seeing how each is classified
def good_artis_sim():
    classes = {0: 0, 10: 0, 20: 0, 30: 0, 40: 0, 50: 0}
    NUM_TRIALS = 10000
    
    for i in range(NUM_TRIALS):    
        piece_set, artifact_type, mainstat, substats = G.make_piece()
        roll_dict = G.roll_sim(artifact_type, mainstat, substats)
        cv = G.cv_classifier(roll_dict)
        classes[(cv // 10) * 10] += 1
    
    # normalize the amounts of each class and format to classes
    for key, value in classes.items():
        classes[key] = round(value/NUM_TRIALS, 4)
        classes[key] = str(round(classes[key] * 100, 2)) + '%'
                        
    # display information in dictionary
    for key, value in classes.items():
        print(f'{ut.ANSI.BLUE}{value}{ut.ANSI.RESET} of artifacts had a crit value from {key} to {key + 10}')
    

def main():
    sim_dict = {1: 'Simulate Rolling 1 Artifact', 2: 'Simulate Rolling Artifact with n+ CV', 3: 'Simulate Building a Character', 4: 'Count Good Artifacts Simulation'}
    
    while True:
        print(f'\n{ut.ANSI.BOLD}Available Sims:{ut.ANSI.RESET}')  # display available CSVs
        for i in range(len(sim_dict)): print(f'{i + 1}. {str(sim_dict[i + 1])}')
        
        u_input = input(f'Please enter {ut.ANSI.GREEN}Sim number{ut.ANSI.RESET} (e.g. 1, 2 ...) or enter \'END\': ') 
        if u_input == 'END': break  # end loop
        
        if u_input == '1': display_sim()
        elif u_input == '2': cv30_display_sim()
        elif u_input == '3': build_sim()
        elif u_input == '4': good_artis_sim()


if __name__ == '__main__':
    main()